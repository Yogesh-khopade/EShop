package entity;

public enum Category {
	
	A(10),B(20),C(0);
	
	private int tax;
	Category(int tax)
	{
		this.tax=tax;
	}
	public int getTax()
	{
		return tax;
	}
}
